%%not used
function [clipStart,clipEnd] = findToleranceWindow(T,l1,l2)
    clipStart = min(T);
    clipEnd = max(T);
    tolerance = 2; %2 seconds
    lengthOfClip = T(l2) - T(l1);
    if(lengthOfClip > 30 )
        lengthOfClip = 30;
    end

    if(max(T) > 5.5)
        if(T(l1)-tolerance > 0)
            clipStart = T(l1)-2;
        end
        if(T(l2)+tolerance < max(T))
            clipEnd = clipStart + lengthOfClip + 4;
        else
            clipEnd = max(T);
        end
    end
end