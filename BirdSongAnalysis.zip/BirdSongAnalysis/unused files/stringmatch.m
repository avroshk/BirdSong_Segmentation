function [ M,I,V ] = stringmatch( x )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

    A = [1,1,1,1,0,0,0,0,1,1,1,0,0,1,1]'; % Transpose to row vector.
    [S,E] = regexp(sprintf('%i',x),'[1]+?([0]{0,2})[1]+');
    [M,I] = max(cellfun('length',M));
    M = M + 1;  % Holds the max length.
    I = V(I)-1;  % Holds the starting index of first run of length M.
    V = A(I);  % The value of the run.


end

