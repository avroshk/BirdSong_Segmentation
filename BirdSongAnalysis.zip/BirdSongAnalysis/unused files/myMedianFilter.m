function [filteredSignal] = myMedianFilter(signal,blockSize)
end