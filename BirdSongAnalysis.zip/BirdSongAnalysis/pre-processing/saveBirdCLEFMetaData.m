%%Bird Song Analysis
%arguments : windowSize, hopSize
% return : features, metadata 

function [metadata, songs, fs, missingIndexes, count, fileIds] = saveBirdCLEFMetaData(startIndex,numFiles)
    
%     13813
%     numMetaData = 21
    fs_44k = 44100;
    songs = zeros(numFiles,fs_44k*40);
    fs = zeros(numFiles,1);
    fileIds = zeros(numFiles,1);
    metadata = struct('MetaData',0);
    
     %detect classes
%     classes = cell(numFiles,1);
    
    audioFiles = cell(numFiles,1);
    metaFiles = cell(numFiles,1);
    
    path = 'LIFECLEF2014_BIRDAMAZON_XC_WAV_RN';
    wavExtension = '.wav';
    xmlExtension = '.xml';    
    
    
    for i=startIndex:numFiles
        audioFiles{i,1} = strcat(path,num2str(i),wavExtension);
        metaFiles{i,1} = strcat(path,num2str(i),xmlExtension);
    end
    
    %collect indexes of missing files
    missingIndexes = [];
%     missingFamily = [];
    
    count = 0;

%     fs_22k = 22050;
%     blockLength = 1024;
%     hopLength = 512;
%     hannWindow = hann(blockLength,'periodic');
    
    for j=startIndex:numFiles
        try
            s= xml2struct(char(metaFiles(j,1)));
            count = count + 1;
            fileIds(count) = j;
            disp(j);
            metadata(count).MetaData  = s.Audio;
            [temp_song, fs(count)] = audioread(char(audioFiles(j,1)));
            
            if length(temp_song)/fs(count) >= 40
                songs(count,:) = temp_song(1:40*fs(count))';
            else 
                songs(count,:) = [temp_song' zeros(1,40*fs(count)-length(temp_song))];
            end
                        
%                         if length(classes)==0
%                             classes = [classes; s.Audio.Content.Text]; 
%                         else
%                             currentSize = size(classes);
%                             flag = 0;
%                             for k=1:currentSize(1)
%                                 if strcmp(s.Audio.Content.Text, classes(k,:))
%                                     flag = 1;
%                                 end
%                             end
%                             if flag == 0
%                                 classes = [classes; s.Audio.Content.Text];
%                             end 
%                         end 
%  
                    
%                     end
%                 end
%             end
                

 
        catch ME
            missingIndexes = [missingIndexes;j];
        end
    end
end