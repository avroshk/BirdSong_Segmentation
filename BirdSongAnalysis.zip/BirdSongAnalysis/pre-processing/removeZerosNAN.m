nans = isnan(features(:, 1));
indices = find(nans == 0);

newFeatures = features(indices, :);
newSegmentedFeatures = featuresSegmented(indices, :);
newClasses = classes(indices);

a = find(newFeatures(:, 1) ~= 0);

newFeatures = newFeatures(a, :);
newSegmentedFeatures = newSegmentedFeatures(a,:);
newClasses = newClasses(a);