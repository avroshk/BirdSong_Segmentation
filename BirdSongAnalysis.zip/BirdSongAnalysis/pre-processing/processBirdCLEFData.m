%%Bird Song Analysis
%arguments : windowSize, hopSize
% return : features, metadata 

function [features, featuresSegmented, classes, clipBoundaries, missingIndexes, count] = processBirdCLEFData(startIndex,numFiles,numFeatures)

    missingIndexes = [];
    fs_44k = 44100;
%     songs = zeros(numFiles,fs_44k*40);
%     fs = zeros(numFiles,1);
    maxRows = numFiles*8;
    fileIds = zeros(maxRows,1);
    metadata = struct('MetaData',0);

    clipBoundaries = zeros(maxRows,2);
    
    features = zeros(maxRows, numFeatures);
    featuresSegmented = zeros(maxRows, numFeatures);
    
     %detect classes
    classes = cell(maxRows,1);
    
        
    audioFiles = cell(numFiles,1);
    metaFiles = cell(numFiles,1);
    
    path = 'LIFECLEF2014_BIRDAMAZON_XC_WAV_RN';
    wavExtension = '.wav';
    xmlExtension = '.xml';    
    
    
    for i=startIndex:numFiles
        audioFiles{i,1} = strcat(path,num2str(i),wavExtension);
        metaFiles{i,1} = strcat(path,num2str(i),xmlExtension);
    end
    
    count = 0;
  
    fs_22k = 22050;
    blockLength = 1024;
    hopLength = 512;
    hannWindow = hann(blockLength,'periodic');
    
    for j=startIndex:numFiles
        try
            s= xml2struct(char(metaFiles(j,1)));
%             metadata(j).MetaData  = s.Audio;
            
%             if (strcmp(metadata(j).MetaData.Quality.Text,'1'))
%                 if (isempty(metadata(j).MetaData.BackgroundSpecies.Text))
%                     if ~(isempty(strfind(metadata(j).MetaData.Content.Text,'song')))
            
                       disp(j); 
                        
                        
%                         disp(metadata(j).MetaData.Quality.Text);
%                         disp(metadata(j).MetaData.BackgroundSpecies.Text);
                        song_noisy = audioread(char(audioFiles(j,1)));
                        
                        if length(song_noisy)/fs_44k > 40
                            song_clipped = song_noisy(1:40*fs_44k);
                        else
                            song_clipped = song_noisy;
                        end
                        
%                         song  = song_noisy;
%                         subplot(6,1,1);
%                         plot(song_noisy);
%                         song = denoise_song(song_clipped,fs_44k);
%                         subplot(6,1,2);
%                         plot(song);
%                         song_22k = resample(song,fs_22k,fs_44k);
                        
                        song_22k = denoise_song(resample(song_clipped,fs_22k,fs_44k),fs_22k);

                        ws = blockLength;
                        hs = hopLength;
                        
%                         figure;
%                         spectrogram(song,hannWindow,ws-hs,ws,fs_44k,'yaxis'); colormap bone; colorbar off; 
%                         figure;
%                         spectrogram(song_22k,hannWindow,ws-hs,ws,fs_22k,'yaxis');colormap bone; colorbar off; 
%                         figure;
%                         spectrogram(song_check,hannWindow,ws-hs,ws,fs_22k,'yaxis');colormap bone; colorbar off; 
% %                         player1 = audioplayer(song_noisy,fs_44k);
% %                         player2 = audioplayer(song_22k,fs_22k);
%                         song_22k = removeMedian(song_22k);
%                       
                       
                        
                        [~,~,T] = spectrogram(song_22k,hannWindow,ws-hs,ws,fs_22k,'yaxis'); 
                       
                        %% Segmentation %%
                        numIterations = 8;
                        while (max(T) > 5 && numIterations > 0)
                                                   
                            
                             [l1 l2] = segmentation(song_22k,fs_22k,hannWindow,ws,hs);
%                              rms = ComputeFeature('TimeRms',song_22k(l1*hs:l2*hs),fs_22k,hannWindow,ws,hs);
%                              mean_rms = mean(abs(rms));
                              
                             count = count + 1;
                             fileIds(count) = j;
                                
%                               %------
%                                 subplot(2, 1, 1); spectrogram(song_22k,hannWindow,ws-hs,ws,fs_22k,'yaxis'); colormap bone; colorbar off; 
%                                 hold on;
%                                 if (max(T) > 60)
%                                    rectangle('Position',[T(l1)/60 0 (T(l2)-T(l1))/60 11],'EdgeColor','r');
%                                 else
%                                    rectangle('Position',[T(l1) 0 T(l2)-T(l1) 11],'EdgeColor','r');
%                                 end
%                                 plot_red = plot(0,'r');
%                                 legend(plot_red,'Detected Phrase','northwest');
%                                 
%                                 title('Spectrogram');
%                                 hold off;
%                                %--------
                        
%                              features(count,:) = extractFeatures(song_22k,hannWindow,blockLength,hopLength,fs_22k);
%                                featuresSegmented(count,:) = extractFeatures(song_22k(round(clipStart*fs_22k):round(clipEnd*fs_22k)),hannWindow,blockLength,hopLength,fs_22k);                         
                                featuresSegmented(count,:) = extractFeatures(song_22k(round(l1*hs):round(l2*hs)),hannWindow,blockLength,hopLength,fs_22k);                         
                                classes(count,1) = cellstr(s.Audio.Species.Text);
                                %------------------------%
                             song_22k = [song_22k(1:l1*hs); song_22k(l2*hs:end)];
                             [~,~,T] = spectrogram(song_22k,hannWindow,ws-hs,ws,fs_22k,'yaxis'); 
%                              mean(mean(abs(S(:,l1:l2))));
                             numIterations = numIterations - 1;
                        end
                        
                       
                        
                        
%                         subplot(2, 1, 2);imagesc(E); hold on; 
%                         xlabel('Time (number of blocks)');
% %                         ylabel(');
%                         title('Self-similarity Lag Matrix');
                        
%                         rectangle('Position',[l1 0 l2-l1 length(E)],'EdgeColor','r'); hold off;
%                         [S,c,T]= spectrogram(song_22k,hannWindow,ws-hs,ws,fs_22k,'yaxis');
%                         subplot(2, 1, 1); spectrogram(song_22k,hannWindow,ws-hs,ws,fs_22k,'yaxis'); colormap bone; colorbar off; 
%                         hold on;
%                         if (max(T) > 60)
%                            rectangle('Position',[T(l1)/60 0 (T(l2)-T(l1))/60 11],'EdgeColor','r');
%                         else
%                            rectangle('Position',[T(l1) 0 T(l2)-T(l1) 11],'EdgeColor','r');
%                         end
%                             
%                         hold off;

                        %%
                      
%                         clipBoundaries(count,:) = findToleranceWindow(T,l1,l2);
                        
                        
%                         hold on; 
%                         if (max(T) > 60)
%                             rectangle('Position',[clipStart/60 0 (clipEnd-clipStart)/60 11],'EdgeColor','g');                          
%                         else
%                             rectangle('Position',[clipStart 0 clipEnd-clipStart 11],'EdgeColor','g');
%                         end
%                         plot_red = plot(0,'r');
%                         plot_green = plot(0,'g');
%                         legend([plot_red,plot_green],'Detected Phrase','Phrase with Tolerance Window','Location','northwest');
% %                         legend([plot_red,plot_green],'Detected Phrase','Phrase with Tolerance Window');
%                         title('Spectrogram');
%                         
%                         corrA = song_22k;
%                         corrB = song_22k(T(l1):T(l2));
%                         
%                         [corrC,lag] = xcorr(corrA,corrB);
                                               
%                         hold off;

                        

%                         pitchchroma = ComputeFeature('SpectralPitchChroma',song_filt1,fs_22k,hannWindow,blockLength,hopLength);

            %             imagesc(pitchchroma);

%                         if length(classes)==0
%                             classes = [classes; s.Audio.Content.Text]; 
%                         else
%                             currentSize = size(classes);
%                             flag = 0;
%                             for k=1:currentSize(1)
%                                 if strcmp(s.Audio.Content.Text, classes(k,:))
%                                     flag = 1;
%                                 end
%                             end
%                             if flag == 0
%                                 classes = [classes; s.Audio.Content.Text];
%                             end 
%                         end 
%  
                    
%                     end
%                 end
%             end
                

 
        catch ME
            missingIndexes = [missingIndexes;j];
        end
    end
end