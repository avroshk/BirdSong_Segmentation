%testScript
clear;
% [metadata, songs, fs, missingIndexes, count, fileIds] = saveBirdCLEFMetaData(1,1000);
% [features, featuresSegmented, classes, clipBoundaries, missingIndexes] = getBirdCLEFMetaData();
startIndex = 1;
numFiles = 14027;
numFeatures = 86;
[features, featuresSegmented, classes, clipBoundaries, missingIndexes, count] = processBirdCLEFData(startIndex,numFiles,numFeatures);


%Get rid of empty rows
classes = classes(1:count);
clipBoundaries = clipBoundaries(1:count,:);
features = features(1:count,:);
featuresSegmented = featuresSegmented(1:count,:);

save('RUN2');

%  csvwrite('mfcc_dataset.csv',[features transformed_classes]);