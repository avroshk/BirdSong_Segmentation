%% compute lag distance matrix 
% input:
%   SDM: numSamples by numSamples float matrix, self-distance matrix
% output:
%   R: numSamples by numSamples float matrix, lag-distance matrix
% Note: R should be a triangular matrix, xaxis = time, yaxis = lag
%       for more details, please refer to Figure 2 in the reference
%       "Paulus et al., Audio-based Music Structure Analysis, 2010"

function R = computeLagDistMatrix(SDM)
    R = zeros(length(SDM));
    
    for i=1:length(SDM)
        for j=1:i-1
            R(i,i-j) = SDM(i,j);
        end
    end
    
    R = rot90(R);
end



