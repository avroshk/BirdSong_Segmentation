function [l1 l2] = segmentation(song,fs,window,ws,hs)

    features_mfcc = ComputeFeature('SpectralMfccs',song,fs,window,ws,hs);

    %compute SDM
    D_mfcc = computeSelfDistMat(features_mfcc);
%                         kernel_size = 6;
%                         MFCC = computeSdmNovelty(D_mfcc,kernel_size);
    %compute lag matrix
    R = computeLagDistMatrix(D_mfcc);

    %Estimate the threshold for binary conversion
    mean1 = mean(mean(R(R>0)));                        
    mean2 = mean(mean(R));
    mean3 = abs(mean2-mean1);
    if(mean1>mean2) 
        final_mean=mean1-mean3/2;
    else
        final_mean=mean2-mean3/2;
    end

    SDM_mfcc_bin = computeBinSdm(R,final_mean);

    % imagesc(SDM_mfcc_bin);
    phraseLength = 30;
    E = erodeDilate(SDM_mfcc_bin,phraseLength);

    [l1,l2] = findPhrase(E);

    if l1==0
        l1 = 1;
    end
    
%     %plot----
%     subplot(2, 1, 2);imagesc(E); hold on; 
%     xlabel('Time (number of blocks)');
%     rectangle('Position',[l1 0 l2-l1 length(E)],'EdgeColor','r'); hold off;
%     %plot----
%     title('Self-similarity Lag Matrix');
    
end