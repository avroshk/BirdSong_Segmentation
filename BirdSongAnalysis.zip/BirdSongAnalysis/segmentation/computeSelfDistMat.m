%% compute self-distance matrix
% input:
%   featureMatrix: numFeatures by numSamples float matrix, feature matrix
% output:
%   SDM: numSamples by numSamples float matrix, self-distance matrix

function SDM = computeSelfDistMat(featureMatrix)
    [numCoeff,numBlocks] = size(featureMatrix);
    
    Na = featureMatrix;
    Nb = fliplr(featureMatrix);
    
    Na = repmat(Na,[1,1,numBlocks]);
    Nb = repmat(Nb,[1,1,numBlocks]);
    
    Nb = permute(Nb,[1 3 2]);
    
    D = Na - Nb;
    
    D = D.*D;
    
    SDM = fliplr(squeeze(sqrt(sum(D,1))));
    
end