function [features] = extractFeatures(x,window,blockLength,hopLength,fs)
    numFeatures = 86;
    
    features = zeros(1,numFeatures);
    
    blockedX = blockHamIt(x,blockLength, hopLength);
    numBlocks = size(blockedX,2);
    %Calculate fft of all blocks
    fft_blockedX = abs(fft(blockedX));
    %Truncate the fft
    fft_blockedX = fft_blockedX(1:blockLength/2,:);
    %Get Spectral Crest
    spectral_crest = mySpectralCrest(fft_blockedX,blockLength,numBlocks);
    
    spectral_flux = ComputeFeature('SpectralFlux',x,fs,window,blockLength,hopLength);   
    spectral_centroid = ComputeFeature('SpectralCentroid',x,fs,window,blockLength,hopLength);
    spectral_rolloff = ComputeFeature('SpectralRolloff',x,fs,window,blockLength,hopLength);
    spectral_flatness = ComputeFeature('SpectralFlatness',x,fs,window,blockLength,hopLength);
    zcr = ComputeFeature('TimeZeroCrossingRate',x,fs,window,blockLength,hopLength);
    mfcc = ComputeFeature('SpectralMfccs',x,fs,window,blockLength,hopLength);
    pitch_chroma = ComputeFeature('SpectralPitchChroma',x,fs,window,blockLength,hopLength);
    
    
    diff_pitch_chroma = zeros(size(pitch_chroma));
    diff_pitch_chroma(:,2:end) = pitch_chroma(:,1:end-1);
    
    diff_pitch_chroma = diff_pitch_chroma - pitch_chroma;
    
    
    
    
%     
    features(1) = mean(spectral_flux);
    features(2) = std(spectral_flux);
%     
    features(3) = mean(spectral_centroid);
    features(4) = std(spectral_centroid);
    
    features(5) = mean(spectral_rolloff);
    features(6) = std(spectral_rolloff);
    
    features(7) = mean(spectral_flatness);
    features(8) = std(spectral_flatness);
    
    features(9) = mean(zcr);
    features(10) = std(zcr);
    
    features(11) = mean(spectral_crest);
    features(12) = std(spectral_crest);
%     
    features(13:25) = mean(mfcc,2);
    features(26:38) = std(mfcc,0,2);
    
    features(39:50) = mean(pitch_chroma,2);
    features(51:62) = std(pitch_chroma,0,2);
    
    features(63:74) = mean(diff_pitch_chroma,2);
    features(75:86) = std(diff_pitch_chroma,0,2);
    
   
    
end