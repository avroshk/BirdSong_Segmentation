%% Novelty function: spectral flux
% [nvt] = mySpectralFlux(blockedX, windowSize,numBlocks)
% input: 
%   blockedX: N by M float vector, blocked input signal
%   windowSize: int, number of samples per block
%   numBlocks: int, number of blocks
% output: 
%   nvt: n by 1 float vector, the resulting novelty function 

function [nvt] = mySpectralFlux(fft_blockedX, windowSize, numBlocks)
    
    fft_shifted_blockedX = zeros(windowSize/2,1);
    fft_shifted_blockedX = [fft_blockedX(:,2:numBlocks)';fft_shifted_blockedX']';
    
    temp_container = fft_blockedX - fft_shifted_blockedX;
    temp_container = temp_container.^2;
    temp_container = sum(temp_container);
    
    nvt = 2*sqrt(temp_container)/windowSize; 
end