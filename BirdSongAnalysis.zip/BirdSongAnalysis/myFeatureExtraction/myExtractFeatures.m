%% Extract features: 
% [nvt] = extractFeatures(x, windowSize, hopSize)
% input: 
%   x: N by 1 float vector, blocked input signal
%   windowSize: int, number of samples per block
%   hopSize: int, number of samples per hop
% output: 
%   feature vector [features]: 10 by 1 float vector, the resulting novelty function 

function [features] = myExtractFeatures(x, windowSize, hopSize, fs)

    %Block the input signal
    blockedX = blockHamIt(x,windowSize, hopSize);
    
    blockedX_NoHam = blockIt(x,windowSize, hopSize);
    
    %Read the number of blocks formed from the signal
    numBlocks = size(blockedX); 
    numBlocks = numBlocks(2);
    
     %Calculate fft of all blocks
    fft_blockedX = abs(fft(blockedX));
    
    %Truncate the fft
    fft_blockedX = fft_blockedX(1:windowSize/2,:);
    
    % Get Spectral Flux
    flux = mySpectralFlux(fft_blockedX,windowSize,numBlocks);
    
    %Get Spectral Centroid
    spectral_centroid = mySpectralCentroid(fft_blockedX,windowSize,numBlocks);
    
    %Get Maximum Envelope
    max_envelope = myMaxEnvelope(blockedX_NoHam,windowSize,numBlocks);
    
    %Get Zero Crossing Rate
    zcr = myZCR(blockedX_NoHam,windowSize,numBlocks);
    
    %Get Spectral Crest
    spectral_crest = mySpectralCrest(fft_blockedX,windowSize,numBlocks);
    
    features = zeros(1,10);
    
    features(1) = mean(flux);
    features(2) = std(flux);
    
    features(3) = mean(spectral_centroid);
    features(4) = std(spectral_centroid);
    
    features(5) = mean(max_envelope);
    features(6) = std(max_envelope);
    
    features(7) = mean(zcr);
    features(8) = std(zcr);
    
    features(9) = mean(spectral_crest);
    features(10) = std(spectral_crest);
    
end