%% Novelty function: spectral centroid
% [nvt] = mySpectralCentroid(fft_blockedX, windowSize, numBlocks)
% input: 
%   fft_blockedX: N by M float vector, truncated fft of blocked input signal
%   windowSize: int, number of samples per block
%   numBlocks: int, number of blocks
% output: 
%   nvt: n by 1 float vector, the resulting novelty function 

function [nvt] = mySpectralCentroid(fft_blockedX, windowSize, numBlocks)
    
    fft_squared_blockedX = fft_blockedX.^2;
    
    position_vector = (1:(windowSize/2))';
    position_vector = repmat(position_vector,1,numBlocks);
    
    nvt = sum(position_vector.*fft_squared_blockedX)./sum(fft_squared_blockedX); 
    
    nvt(isnan(nvt)) = 0;
end