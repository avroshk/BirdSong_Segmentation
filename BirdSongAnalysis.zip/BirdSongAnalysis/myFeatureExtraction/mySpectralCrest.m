%% Novelty function: spectral crest
% [nvt] = mySpectralCrest(fft_blockedX, windowSize, numBlocks)
% input: 
%   fft_blockedX: N by M float vector, truncated fft of blocked input signal
%   windowSize: int, number of samples per block
%   numBlocks: int, number of blocks
% output: 
%   nvt: n by 1 float vector, the resulting novelty function 

function [nvt] = mySpectralCrest(fft_blockedX, windowSize, numBlocks)
     
    nvt = max(fft_blockedX)./sum(fft_blockedX);
    nvt(isnan(nvt)) = 0;  
end