%% Novelty function: Maximum Envelope
% [nvt] = myMaxEnvelope(blockedX, windowSize, numBlocks)
% input: 
%   blockedX: N by M float vector, blocked input signal
%   windowSize: int, number of samples per block
%   numBlocks: int, number of blocks
% output: 
%   nvt: n by 1 float vector, the resulting novelty function 

function [nvt] = myMaxEnvelope(blockedX, windowSize, numBlocks)
    
    nvt = max(blockedX); 
end