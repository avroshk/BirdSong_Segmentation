clear;

 
load('RUN1-withclassindexes.mat');
n = 10;
K = 3;

numFiles = 9680;
%numFiles = 27100;

featureStartIndex = 12;
featureEndIndex = 38;

[accuracy] = nFoldValidationSVM(features(1:numFiles,featureStartIndex:featureEndIndex),transformed_classes(1:numFiles),n,K);


